-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 25, 2014 at 11:49 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nhipp38`
--

-- --------------------------------------------------------

--
-- Table structure for table `choice`
--

CREATE TABLE IF NOT EXISTS `choice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `choice`
--

INSERT INTO `choice` (`id`, `u_id`, `c_id`) VALUES
(7, 9, 2),
(3, 10, 3),
(6, 9, 3),
(8, 5, 4),
(9, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`sn`, `nick`, `fullname`) VALUES
(1, 'NHF', 'New Horizons Foundation'),
(2, 'NHIPP', 'New Horizons Internet Professional Program'),
(3, 'Java', 'Java'),
(4, 'C/C++', 'C/C++');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE IF NOT EXISTS `info` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  `Email` text COLLATE utf8_unicode_ci NOT NULL,
  `User` text COLLATE utf8_unicode_ci NOT NULL,
  `Pass` text COLLATE utf8_unicode_ci NOT NULL,
  `Section` text COLLATE utf8_unicode_ci NOT NULL,
  `Shift` text COLLATE utf8_unicode_ci NOT NULL,
  `More` longtext COLLATE utf8_unicode_ci NOT NULL,
  `Image` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`Id`, `Name`, `Email`, `User`, `Pass`, `Section`, `Shift`, `More`, `Image`) VALUES
(1, 'New Horizons', 'abc@def.com', 'user', '123', 'Design', 'Day', 'More Info updated', 'demo.png'),
(5, 'Mamun', 'abc@def.com', 'mamun', '123', 'Design,Development', 'Evening', 'Nothing ', '1413543321_nhipp_38.png'),
(6, 'Mr. Someone', 'mr@tareq.com', 'me', '12', 'Design,Development', 'Evening', 'Demo', '1411818060_nhipp_38.jpg'),
(9, 'Tamim', 'abc@def.com', 'ggg', 'ggg', 'Design,Development', 'Evening', 'test', 'demo.png'),
(10, 'Ana', 'ana@adsjflkaj.com', 'user2', '1232', 'Design,Development', 'Evening', 'test', 'demo.png');
